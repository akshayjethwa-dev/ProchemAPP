// src/constants/index.ts
export const CATEGORIES = [
  'Pharma Grade Acids',
  'Industrial Solvents',
  'Agro Chemicals',
  'Food Grade',
  'Lab Reagents'
];
